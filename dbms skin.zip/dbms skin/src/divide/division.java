package divide;

public class division {

    int t;
    int a,b,c;

    public division(int t,int a,int b,int c){
        this.t=t;
        this.a=a;
        this.b=b;
        this.c=c;
    }
}
